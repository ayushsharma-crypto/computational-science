# Calculating Potential energy of a system of water molecules

## Run the file using command

        Python3 code.py

## Requirements

* math