# Analysis of Random Walks


**Executing the code :**

    For plotting different part of the question on graph please uncomment accordingly the last 10 lines of the file `code.py` as directed.
    As follwowing:-

    ```python3

    # uncomment line 231 for part1 and run the file using cmd "python code.py" then wait until simulation gets over
    # p_meeting()

    # uncomment line 234 for part2 and run the file using cmd "python code.py" then wait until simulation gets over
    # p_origin()

    # uncomment line 237 for part3 and run the file using cmd "python code.py" then wait until simulation gets over
    # mean_displacement()

    # uncomment line 240 for part4 and run the file using cmd "python code.py" then wait until simulation gets over
    # meansq_displacement()

    ```

    Then run command : `python3 code.py`

**Output :**

    There will be a graph output for each function call as shown above.
    Time of simulation : ~2-3 minutes